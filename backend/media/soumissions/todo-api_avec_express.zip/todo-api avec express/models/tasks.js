const { v4: uuidv4 } = require('uuid');

let tasks = [];

const getAllTasks = () => tasks;

const getTaskById = (id) => tasks.find(task => task.id === id);

const addTask = (title) => {
    const newTask = { id: uuidv4(), title, completed: false };
    tasks.push(newTask);
    return newTask;
};

const updateTask = (id, title, completed) => {
    const task = tasks.find(t => t.id === id);
    if (task) {
        if (title !== undefined) task.title = title;
        if (completed !== undefined) task.completed = completed;
        return task;
    }
    return null;
};

const deleteTask = (id) => {
    const initialLength = tasks.length;
    tasks = tasks.filter(task => task.id !== id);
    return tasks.length < initialLength;
};

module.exports = {
    getAllTasks,
    getTaskById,
    addTask,
    updateTask,
    deleteTask
};
