const taskModel = require('../models/tasks');

const getAllTasks = (req, res) => {
    res.json(taskModel.getAllTasks());
};

const getTaskById = (req, res) => {
    const task = taskModel.getTaskById(parseInt(req.params.id));
    if (task) {
        res.json(task);
    } else {
        res.status(404).json({ message: 'Tâche non trouvée' });
    }
};

const addTask = (req, res) => {
    const { title } = req.body;
    if (!title) {
        return res.status(400).json({ message: 'Le titre est requis' });
    }
    const newTask = taskModel.addTask(title);
    res.status(201).json(newTask);
};

const updateTask = (req, res) => {
    const updatedTask = taskModel.updateTask(parseInt(req.params.id), req.body.title, req.body.completed);
    if (updatedTask) {
        res.json(updatedTask);
    } else {
        res.status(404).json({ message: 'Tâche non trouvée' });
    }
};

const deleteTask = (req, res) => {
    const isDeleted = taskModel.deleteTask(parseInt(req.params.id));
    if (isDeleted) {
        res.json({ message: 'Tâche supprimée' });
    } else {
        res.status(404).json({ message: 'Tâche non trouvée' });
    }
};

module.exports = { getAllTasks, getTaskById, addTask, updateTask, deleteTask };
