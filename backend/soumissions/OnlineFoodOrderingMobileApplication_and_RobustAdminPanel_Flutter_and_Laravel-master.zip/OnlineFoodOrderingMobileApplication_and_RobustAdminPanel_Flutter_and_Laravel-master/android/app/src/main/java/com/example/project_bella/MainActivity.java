package com.example.project_bella;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
